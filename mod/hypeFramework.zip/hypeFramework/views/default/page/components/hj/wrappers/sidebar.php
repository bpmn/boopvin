<div id="hj-layout-sidebar" class="<?php echo $vars['subclass'] ?>">
    <?php echo $vars['content'] ?>
</div>
