<div class="profile elgg-col-3of3">
    <div class="elgg-inner clearfix">
        <div id="profile-owner-block">
            <?php echo $vars['sidebar'] ?>
        </div>
        <div id="profile-details" class="elgg-body pll">
            <?php echo $vars['content'] ?>
        </div>
    </div>
</div>
