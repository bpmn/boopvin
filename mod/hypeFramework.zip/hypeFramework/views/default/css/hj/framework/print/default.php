<?php
echo "<style type=\"text/css\">";
echo elgg_view('css/elgg');
echo "</style>";
?>
