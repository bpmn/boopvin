<?php
/**
 *	Elgg - Live notification plugin
 *	Author : Sarath C | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg-live notification bridge
 * 	Plugin info : Ajax live notification plugin for Elgg
 *	Licence : Commercial
 *	Copyright : Team Webgalli 2011-2012
 */
    function live_notification_init() {
		elgg_register_library('elgg:live_notification', elgg_get_plugins_path() . 'live_notification/lib/live_notification.php');
		elgg_load_library('elgg:live_notification');
	}
	elgg_register_event_handler('init','system','live_notification_init');	
?>