<?php
/**
 *	Elgg - Live notification plugin
 *	Author : Sarath C | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg-live notification bridge
 * 	Plugin info : Ajax live notification plugin for Elgg
 *	Licence : Commercial
 *	Copyright : Team Webgalli 2011-2012
 */
$options = array('type' => 'user', 'count' => true);
$count = elgg_get_entities($options);

$options = array('type' => 'user', 'limit' => $count);
$users = elgg_get_entities($options);

foreach ($users as $user){
	set_user_notification_setting($user->guid, 'live', true);
}