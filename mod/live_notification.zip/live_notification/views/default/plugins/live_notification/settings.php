<?php
/**
 *	Elgg - Live notification plugin
 *	Author : Sarath C | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg-live notification bridge
 * 	Plugin info : Ajax live notification plugin for Elgg
 *	Licence : Commercial
 *	Copyright : Team Webgalli 2011-2012
 */
echo '<div>';
echo elgg_echo("Licence key for the live notification plugin. You can get one at <a href='http://webgalli.com/mod/webgalli_licence/key.php?group_guid=3730'> plugin home page</a>");
echo elgg_view('input/text', array(
	'name' => 'params[licecnce_key]',
	'value' => $vars['entity']->licecnce_key,
));
echo '</div>';
live_notification_licenceCheck();