<?php
/**
 *	Elgg - Live notification plugin
 *	Author : Sarath C | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg-live notification bridge
 * 	Plugin info : Ajax live notification plugin for Elgg
 *	Licence : Commercial
 *	Copyright : Team Webgalli 2011-2012
 */
	
	$live_notification = $vars['entity'];
	$notify_guid = $live_notification->getGUID();
	$friendlytime = elgg_view_friendly_time($live_notification->time_created);
	$desc = $live_notification->desc;
	$owner = $live_notification->getOwnerEntity();
	$action_user = get_entity($live_notification->action_user);
	$url = elgg_get_site_url();
	$readYet = $live_notification->readYet;
	if ($readYet != 1){
		$class = "live_notification_unread";
		?>
		<script language="javascript"> 	
		function process_<?php echo $notify_guid;?>(){
		$("#none").load("<?php echo $url; ?>mod/live_notification/endpoint/process.php?guid=<?php echo $notify_guid;?>");
		}
		</script>	
		<?php	
	}
	?>	
	<style type="text/css">
		div#<?php echo "live_notification_t_".$notify_guid;?>	{
			margin: 3px 20px;
			border:1px solid #dedede;
			padding:10px;
			display: none;
		}
	</style>
	<div id="none"></div>
	<div <?php if ($readYet != 1){ ?> onclick="process_<?php echo $notify_guid;?>();" <?php } ?> rel="toggle" href="#live_notification_t_<?php echo $notify_guid;?>" class="notifications_content">
		<?php echo elgg_view_entity_icon($action_user, 'tiny', array('hover' => FALSE));?>
		<p><a class="<?php echo $class;?>"><?php echo $live_notification->title;?></a>: by <?php echo $action_user->name;?> <span class="time"><?php echo $friendlytime;?></span></p>
	</div>
	<div id="live_notification_t_<?php echo $notify_guid;?>">
		<?php echo elgg_view('output/longtext', array('value' => $live_notification->desc)); ?>
	</div>