<?php
/**
 *	Elgg - Live notification plugin
 *	Author : Sarath C | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg-live notification bridge
 * 	Plugin info : Ajax live notification plugin for Elgg
 *	Licence : Commercial
 *	Copyright : Team Webgalli 2011-2012
 */
 ?>
 
<div id="notify" style="display:none;">
	<h4><?php echo elgg_echo('live_notification:notifications');?></h4>
	<div class="notification_list_autorefresh" id ="autorefresh_notifications"></div>
    <div class="seeall"><a href="<?php echo $vars['url']; ?>pg/live_notification/"><?php echo elgg_echo('live_notification:all');?></a></div>
</div>