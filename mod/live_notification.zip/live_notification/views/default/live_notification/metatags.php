<?php
/**
 *	Elgg - Live notification plugin
 *	Author : Sarath C | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg-live notification bridge
 * 	Plugin info : Ajax live notification plugin for Elgg
 *	Licence : Commercial
 *	Copyright : Team Webgalli 2011-2012
 */
 ?>
<script language="javascript"> 
 $(document).ready(function() {
	var refresh = function () {
		$("#notification_count_autorefresh").load("<?php echo $vars['url']; ?>mod/live_notification/endpoint/livenum.php");
        $(".notification_list_autorefresh").text("<?php echo elgg_echo('live_notification:loading');?>").load("<?php echo $vars['url']; ?>mod/live_notification/endpoint/data.php");
	}
	setInterval(refresh, 9000);
	refresh();	  
 });
function rename_autorefreshdiv(){
    var name = document.getElementById("autorefresh_notifications")
    var currentClass = name.className;
    if(currentClass == "notification_list_autorefresh"){
        name.className = "notification_list_norefresh";
    } else {
        name.className = "notification_list_autorefresh";
    }
}  
</script>