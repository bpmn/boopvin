<?php
/**
 *	Elgg - Live notification plugin
 *	Author : Sarath C | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg-live notification bridge
 * 	Plugin info : Ajax live notification plugin for Elgg
 *	Licence : Commercial
 *	Copyright : Team Webgalli 2011-2012
 */
?>
.elgg-icon-live-notification {
    background-position: 0 -900px;;
}
.live-notification-new {
    background-color: red;
    border-radius: 10px 10px 10px 10px;
    box-shadow: -2px 2px 4px rgba(0, 0, 0, 0.5);
    color: white;
    font-size: 10px;
    font-weight: bold;
    height: 16px;
    left: 26px;
    min-width: 16px;
    position: absolute;
    text-align: center;
    top: 0;
}

#notificationstable td.livetogglefield {
	width:50px;
	text-align: center;
	vertical-align: middle;
}
#notificationstable td.livetogglefield input {
	margin-right:36px;
	margin-top:5px;
}
#notificationstable td.livetogglefield a {
	width:46px;
	height:24px;
	cursor: pointer;
	display: block;
	outline: none;
}
#notificationstable td.livetogglefield a.livetoggleOff {
	background: url(<?php echo $vars['url']; ?>mod/live_notification/graphics/icon_notifications_live.png) no-repeat right 2px;
}
#notificationstable td.livetogglefield a.livetoggleOn {
	background: url(<?php echo $vars['url']; ?>mod/live_notification/graphics/icon_notifications_live.png) no-repeat right -36px;
}
a#notify_link,a#notify_link.selected,a#notify_link:hover{
	text-decoration:none;
	cursor:pointer;    
}
#notify{
	float:left; 
	position:absolute; 
	background:#FFF; 
	width:450px; 
	min-height:100px; 
	margin:23px 0 0 175px; 
	color:#333;
    border: 1px solid #4690D6;
    border-radius: 6px 6px 6px 6px;
	box-shadow: 1px 1px 5px #CCCCCC;
}
#notify h4{
	margin:2px 0 2px 2px;
	border-bottom:1px #999 solid;
}
#notify .seeall {
	background-color:#D5D9F6;
	padding:6px 0 6px 0;
	text-align:center;
}
#notify .seeall:hover {
	background:#4690d6;
	border-top:1px #3349CC solid;
	border-bottom:1px #3349CC solid;
	text-decoration:none;
	color:#FFF;
}
#notify .seeall:hover a {
	text-decoration:none;
	color:#FFF;
	display: block;
}

.notifications_content{
	font-size:10px;
	margin:3px 2px;
	padding:6px 0px;
	min-height:30px;
}
.notifications_content img{
	margin:1px 5px;
	float:left;
}
.notifications_content p {
    margin: -30px 0 0 40px;
}
.notifications_content a.live_notification_unread {
	color:red;
}
.notifications_content:hover a{
	color:#FFF;
	cursor:pointer;
	text-decoration:none;
}
.notifications_content:hover{
	font-size:10px;
	background:#4690d6;
	color:#FFF;
	cursor:pointer;
}
.notifications_content span.time{
	font-size:8px;
	color:#CCC;
	padding-left:2px;
}