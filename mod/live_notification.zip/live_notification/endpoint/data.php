<?php 
/**
 *	Elgg - Live notification plugin
 *	Author : Sarath C | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg-live notification bridge
 * 	Plugin info : Ajax live notification plugin for Elgg
 *	Licence : Commercial
 *	Copyright : Team Webgalli 2011-2012
 */
	require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/engine/start.php');
	$notifications = get_latest_notifications(5);
	foreach($notifications as $notification){
		echo elgg_view('live_notification/live_notification',array('entity'=>$notification,'topbar'=>TRUE));
	}	
?>