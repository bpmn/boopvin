<?php
/**
 *	Elgg - Live notification plugin
 *	Author : Sarath C | Team Webgalli
 *	Team Webgalli | Elgg developers and consultants
 *	Mail : info@webgalli.com
 *	Web	: http://webgalli.com | http://plugingalaxy.com
 *	Skype : 'team.webgalli'
 *	@package Elgg-live notification bridge
 * 	Plugin info : Ajax live notification plugin for Elgg
 *	Licence : Commercial
 *	Copyright : Team Webgalli 2011-2012
 */
	$english = array(

			'live_notification:all' 			=> "All notifications",
			'live_notification:notifications' 	=> "Notifications",
			'live_notification:loading'			=> "Loading...",
			'live_notification:nonew'			=> "No new notifications",
			'item:object:live_notification' 	=> "Notifications",
			'notification:method:live' 			=> "Live",
	);
	add_translation("en",$english);

?>