<?php
/**
 * General CSS
 */

echo elgg_view_module('info', "Headings", elgg_view('theme_preview/typography/headings'));

echo elgg_view_module('info', "Paragraph", elgg_view('theme_preview/typography/paragraph'));

echo elgg_view_module('info', "Misc", elgg_view('theme_preview/typography/misc'));