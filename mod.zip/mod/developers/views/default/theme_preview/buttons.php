<table class="elgg-table">
	<thead>
		<tr>
			<th></th>
			<th>Default</th>
			<th>Disabled (.elgg-state-disabled)</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<th>Base (.elgg-button)</th>
			<td><a href="#" class="elgg-button">anchor</a></td>
			<td><a href="#" class="elgg-button elgg-state-disabled">anchor</a></td>
		</tr>
		<tr>
			<th>Action (.elgg-button-action)</th>
			<td><a href="#" class="elgg-button elgg-button-action">anchor</a></td>
			<td><a href="#" class="elgg-button elgg-button-action elgg-state-disabled">anchor</a></td>
		</tr>
		<tr>
			<th>Cancel (.elgg-button-cancel)</th>
			<td><a href="#" class="elgg-button elgg-button-cancel">anchor</a></td>
			<td><a href="#" class="elgg-button elgg-button-cancel elgg-state-disabled">anchor</a></td>
		</tr>
		<tr>
			<th>Submit (.elgg-button-submit)</th>
			<td><a href="#" class="elgg-button elgg-button-submit">anchor</a></td>
			<td><a href="#" class="elgg-button elgg-button-submit elgg-state-disabled">anchor</a></td>
		</tr>
		<tr>
			<th>Special (.elgg-button-special)</th>
			<td><a href="#" class="elgg-button elgg-button-special">anchor</a></td>
			<td><a href="#" class="elgg-button elgg-button-special elgg-state-disabled">anchor</a></td>
		</tr>
		<tr>
			<th>Delete (.elgg-button-delete)</th>
			<td><a href="#" class="elgg-button elgg-button-delete">anchor</a></td>
			<td><a href="#" class="elgg-button elgg-button-delete elgg-state-disabled">anchor</a></td>
		</tr>
	</tbody>
</table>