/*#note {margin-top:10px;}*/



.input-degust { margin:0.6% 0% 1% 0%;}

.elgg-form-degusts-edit .input-degust label{
               font-family: arial;
               font-size:95%;
               font-weight: normal;} 

.elgg-form-degusts-edit label {font-family: Georgia, "Times New Roman", Times, serif;} 



                        
.elgg-form-degusts-edit fieldset fieldset {  border-color: black;
                                    border-width: 1px;
                                    border-style: solid;
                                    padding: 2%;
                                    } 
 #degust-profile-box {
 display:inline-block;
 width:100%;
        
 }
 .degust-profile-sections {    
         border-color: black;
         border-width: 1px;
         border-style: solid;
         padding: 2%;}

.degust-main{
    margin-bottom: 5px;
    margin-left: 5px;
    margin-right: 10px;
   
}


.degust-side-head { 
width: auto;
max-height: auto;

padding: 5px;}

.degust-side-head img {
            margin-right: 3px;
            float:left;
            }


.degust-sidebar {
    float: right;
    margin-bottom: 5px;
    margin-left: 5px;
    margin-right: 10px;
    margin-top: 8px;
    padding-bottom:10px;
    padding-left: 10px;
    padding-right: 10px;
    padding-top: 20px;
    position: relative;
    border-width: 1px;
    border-style: solid;
    width: 320px;
}


