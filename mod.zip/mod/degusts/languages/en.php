<?php
/**
 * User dashboard languages
 */

$english = array(
    'degust:complexity'=>'Complexité',   // en fonction du nombres de checkbox cochées.
    'degust:complexity:1'=>'Simple',
    'degust:complexity:2'=>'Medium complexe',
    'degust:complexity:3'=>'Complexe',
    'degust:complexity:4'=>'Very complexe',

        
    
    
    'degust:add'=>"taste"
    
    
    );

add_translation("en", $english);
