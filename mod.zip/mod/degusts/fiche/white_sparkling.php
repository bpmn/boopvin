<?php

/*
 * fiche de dégustaion vin blanc effervescent $kind='white_sparkling'  
 */


//Visuel
$options_mousse=array(          elgg_echo('degust:mousse:inexistante')=>'inexistante',
                                elgg_echo('degust:mousse:faible') => 'faible',
				elgg_echo('degust:mousse:abondante') => 'abondante',
                                elgg_echo('degust:mousse:persistante') => 'persistante');

$options_bulle = array(
				elgg_echo('degust:bulle:tres_fine')=>'tres_fine',
                                elgg_echo('degust:bulle:fine') => 'fine',
				elgg_echo('degust:bulle:moyenne') => 'moyenne',
                                elgg_echo('degust:bulle:grossiere') => 'grossiere');

//Gustatif
$options_palet_bulle = array(
				elgg_echo('degust:palet_bulle:tres_fine')=>'tres_fine',
                                elgg_echo('degust:palet_bulle:fine') => 'fine',
				elgg_echo('degust:palet_bulle:moyenne') => 'moyenne',
                                elgg_echo('degust:palet_bulle:grossiere') => 'grossiere');
                                


?>
