<?php

/*
 * fiche de dégustaion vin rosé effervescent $kind='rose_sparkling'  
 */




?>
