<?php 
/**
 * Blank for compatibility.
 * @deprecated 1.8
 */

elgg_deprecated_notice("The view 'embed/addcontentjs' has been deprecated.", 1.8);
