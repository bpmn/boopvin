<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$french=array(
        'profile' => 'Profile',
	'profile:notfound' => 'Sorry. We could not find the requested profile.',
        'profile:pro'=> 'Travaillez vous dans le milieu du vin ou de la restauration ?',
        'profile:yes'=> 'oui',
        'profile:no'=> 'non',
        'profile:job'=>'Profession',
        'profile:aboutme'=>'A mon sujet...',

    
);

add_translation('fr',$french);

