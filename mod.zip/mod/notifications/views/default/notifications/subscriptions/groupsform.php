<?php 

elgg_deprecated_notice("notifications/subscriptions/groupsform was moved to forms/notificationsettings/groupsave", 1.8);
echo elgg_view('forms/notificationsettings/groupsave');