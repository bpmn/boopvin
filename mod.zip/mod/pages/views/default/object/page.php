<?php
/**
 * Page view
 *
 * @package ElggPages
 */

echo elgg_view('object/page_top', $vars);
