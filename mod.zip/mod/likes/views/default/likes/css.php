<?php
/**
 * Likes CSS
 */
?>

/* ***************************************
	Likes
*************************************** */
.elgg-likes {
	width: 345px;
	position: absolute;
}

.elgg-menu .elgg-menu-item-likes-count {
	margin-left: 3px;
}
