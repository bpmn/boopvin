<?php
/**
 * Elgg invite form wrapper
 *
 * @package ElggInviteFriends
 */

echo elgg_view_form('invitefriends/invite');
