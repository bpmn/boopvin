<?php 

elgg_deprecated_notice("invitefriends/formitems was moved to forms/invitefriends/invite", 1.8);
echo elgg_view('forms/invitefriends/invite');