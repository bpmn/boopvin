<?php
/**
 * Categories CSS extender
 *
 * @package Categories
 */
?>

.categories li label {
	font-size: 100%;
	line-height: 1.2em;
}
