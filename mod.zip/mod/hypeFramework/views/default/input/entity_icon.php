<?php

echo elgg_view('input/file', array(
    'name' => 'icon'
));

