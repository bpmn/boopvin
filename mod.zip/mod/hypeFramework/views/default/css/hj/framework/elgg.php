.elgg-state-draggable .elgg-head:hover {
cursor:move;
}
