<div class="hj-module hj-module-standard">
    <?php echo $vars['content'] ?>

</div>
