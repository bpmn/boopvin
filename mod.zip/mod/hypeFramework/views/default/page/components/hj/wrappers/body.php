<div id="hj-layout-main-column" class="<?php echo $vars['class'] ?>">
        <div class="hj-padding-twenty clearfix">
            <?php echo $vars['content'] ?>
        </div>
</div>
