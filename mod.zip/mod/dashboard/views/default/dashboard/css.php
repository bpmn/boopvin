<?php
/**
 * User dashboard CSS
 */
?>

#dashboard-info {
	border: 2px solid #dedede;
	margin-bottom: 15px;
}
